package com.cleanmind.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class BlockerService : AccessibilityService() {

    companion object {
        const val OFF = 0
        const val REELS = 1
        const val FULL = 2
        const val BREAK = 3
    }

    // ---- Lock ke time band hone wale system screens ----
    private val settingsPkgs = setOf("com.android.settings", "com.miui.securitycenter",
        "com.coloros.safecenter", "com.oplus.safecenter", "com.samsung.android.lool")
    // Phone Manager / Security / Device Care apps (app ko kill ya freeze kar sakte hain)
    private val managerPkgs = setOf(
        "com.coloros.phonemanager", "com.oplus.phonemanager", "com.coloros.oppoguardelf",
        "com.coloros.safecenter", "com.oplus.safecenter", "com.oppo.safe", "com.oplus.battery",
        "com.miui.securitycenter", "com.iqoo.secure", "com.vivo.abe", "com.huawei.systemmanager",
        "com.samsung.android.lool", "com.samsung.android.sm"
    )
    private val installerPkgs = setOf("com.google.android.packageinstaller", "com.android.packageinstaller",
        "com.samsung.android.packageinstaller", "com.miui.packageinstaller")
    private val blockedTitles = listOf(
        "accessibility", "additional settings", "device admin", "device administrator",
        "vpn", "private dns", "date & time", "date and time", "install unknown apps",
        "special app access", "installed services", "downloaded apps",
        "battery optimization", "optimize battery usage", "auto launch", "auto-launch", "autostart", "startup manager",
        "एक्सेसिबिलिटी", "अतिरिक्त सेटिंग", "डिवाइस एडमिन"
    )

    // ---- Porn keyword scan: Chrome + Telegram + Google app ----
    private val watched = setOf(
        "com.android.chrome", "org.telegram.messenger", "org.telegram.messenger.web",
        "org.thunderdog.challegram", "com.google.android.googlequicksearchbox"
    )
    private val keywords = listOf(
        "porn", "xxx", "xvideos", "xnxx", "xhamster", "redtube", "youporn", "brazzers",
        "onlyfans", "hentai", "spankbang", "eporner", "erome", "fapello", "chudai",
        "desi sex", "sex video", "blue film", "camgirl", "adult video", "nude video"
    )

    // ---- Play Store: 13+ rating wale app ka page khulte hi band ----
    private val badRating = Regex("rated for (1[3-9]|[2-9][0-9])\\+|rated for (teen|mature|adults)")

    // ---- Social apps ----
    private val igPkgs = setOf("com.instagram.android", "com.instagram.lite")
    private val fbPkgs = setOf("com.facebook.katana", "com.facebook.lite")
    private val ytPkgs = setOf("com.google.android.youtube")

    // ---- Browsers (Chrome ke alawa sab block) ----
    private var browsers: Set<String> = emptySet()
    private var lastBrowserLoad = 0L

    private var lastScan = 0L
    private var lastVpnCheck = 0L
    private var lastPlay = 0L
    private var lastSocial = 0L
    private var lastSignup = 0L
    private var lastWeb = 0L
    private var lastVpnGuard = 0L

    // Naya account banane ke screens/buttons (exact text match, taaki captions se confuse na ho)
    private val signupScreens = setOf("create account", "create an account", "sign up",
        "sign up with email or phone number", "साइन अप", "खाता बनाएं")
    private val createClicks = listOf("create new account", "नया खाता बनाएं", "create account", "sign up")

    private val handler = Handler(Looper.getMainLooper())
    private var lastTick = 0L
    private val tick = object : Runnable {
        override fun run() {
            try { reelTick() } catch (_: Exception) {}
            if (Lock.isLocked(this@BlockerService)) ensureVpn()
            handler.postDelayed(this, 2000)
        }
    }

    override fun onServiceConnected() {
        loadBrowsers(); ensureVpn()
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        handler.removeCallbacks(tick)
        return super.onUnbind(intent)
    }

    // Har 2 sec: agar reel khuli hai to dekhne ka time gino, 10 min par 5 min break
    private fun reelTick() {
        val now = SystemClock.elapsedRealtime()
        val delta = minOf(now - lastTick, 3000L).coerceAtLeast(0L)
        lastTick = now
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: return
        val key = when {
            pkg in igPkgs -> "ig"
            pkg in fbPkgs -> "fb"
            pkg in ytPkgs -> "yt"
            else -> return
        }
        if (getSharedPreferences("lock", MODE_PRIVATE).getInt("app_$key", OFF) != BREAK) return
        if (!inReels(key, root)) return
        if (ReelBreak.breakLeft(this, key) > 0) { blockDuringBreak(key); return }
        if (ReelBreak.addWatch(this, key, delta)) blockDuringBreak(key)
    }

    private fun blockDuringBreak(key: String) {
        performGlobalAction(GLOBAL_ACTION_BACK)
        val mins = ReelBreak.breakLeft(this, key) / 60000 + 1
        Toast.makeText(this, "Reel break chal raha hai: $mins min baaki", Toast.LENGTH_SHORT).show()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return

        if (System.currentTimeMillis() - lastBrowserLoad > 600_000) loadBrowsers()

        // Instagram/Facebook me "Create new account" dabate hi band
        if (event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED && (pkg in igPkgs || pkg in fbPkgs)) {
            val t = (event.text.joinToString(" ") + " " + (event.contentDescription ?: "")).lowercase()
            if (createClicks.any { t.contains(it) }) { kick("Naya account banana blocked"); return }
        }

        if (Lock.isLocked(this)) {
            ensureVpn()
            if (pkg in managerPkgs) { kick("Lock ke time Phone Manager band"); return }
            if (pkg in settingsPkgs && guardVpnScreen()) return
            if (guardSystemScreens(pkg, event)) return
        }
        when {
            pkg in browsers -> kick("Sirf Chrome allowed hai")
            pkg == "com.android.vending" -> guardPlayStore()
            pkg in igPkgs || pkg in fbPkgs || pkg in ytPkgs -> guardSocial(pkg)
            pkg in watched -> { scanForPorn(); if (pkg == "com.android.chrome") guardWebSignup() }
        }
    }

    // ================= Browsers =================
    private fun loadBrowsers() {
        lastBrowserLoad = System.currentTimeMillis()
        val set = mutableSetOf<String>()
        try {
            val i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER)
            packageManager.queryIntentActivities(i, PackageManager.MATCH_ALL)
                .forEach { set.add(it.activityInfo.packageName) }
        } catch (_: Exception) {}
        set += listOf("org.mozilla.firefox", "org.mozilla.fenix", "com.sec.android.app.sbrowser",
            "com.microsoft.emmx", "com.brave.browser", "com.opera.browser", "com.opera.mini.native",
            "com.UCMobile.intl", "com.duckduckgo.mobile.android", "com.android.browser",
            "com.mi.globalbrowser", "com.heytap.browser", "com.kiwibrowser.browser", "com.vivaldi.browser")
        set.remove("com.android.chrome")
        set.remove(packageName)
        browsers = set
    }

    // ================= Play Store =================
    private fun guardPlayStore() {
        val now = System.currentTimeMillis()
        if (now - lastPlay < 500) return
        lastPlay = now
        if (badRating.containsMatchIn(rootText())) kick("13+ rating wala app. Install nahi hoga")
    }

    // ================= Instagram / Facebook / YouTube =================
    private fun guardSocial(pkg: String) {
        val key = when {
            pkg in igPkgs -> "ig"
            pkg in fbPkgs -> "fb"
            else -> "yt"
        }
        if (key != "yt") {
            val t = System.currentTimeMillis()
            if (t - lastSignup > 500) {
                lastSignup = t
                val r = rootInActiveWindow
                if (r != null && hasSignupText(r)) { kick("Naya account banana blocked"); return }
            }
        }
        val mode = getSharedPreferences("lock", MODE_PRIVATE).getInt("app_$key", OFF)
        if (mode == FULL) { kick("Ye app blocked hai"); return }
        if (mode == BREAK) {
            if (ReelBreak.breakLeft(this, key) > 0) {
                val r = rootInActiveWindow ?: return
                if (inReels(key, r)) blockDuringBreak(key)
            }
            return
        }
        if (mode != REELS) return

        val now = System.currentTimeMillis()
        if (now - lastSocial < 400) return
        lastSocial = now
        val root = rootInActiveWindow ?: return
        if (inReels(key, root)) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            Toast.makeText(this, "Reels/Shorts blocked", Toast.LENGTH_SHORT).show()
        }
    }

    private fun hasSignupText(root: AccessibilityNodeInfo): Boolean {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var n = 0
        while (queue.isNotEmpty() && n < 600) {
            val node = queue.removeFirst()
            n++
            val t = node.text?.toString()?.trim()?.lowercase()
            val d = node.contentDescription?.toString()?.trim()?.lowercase()
            if ((t != null && t in signupScreens) || (d != null && d in signupScreens)) return true
            for (i in 0 until node.childCount) node.getChild(i)?.let { queue.add(it) }
        }
        return false
    }

    // Chrome me instagram.com / facebook.com ka sign up page
    private fun guardWebSignup() {
        val now = System.currentTimeMillis()
        if (now - lastWeb < 600) return
        lastWeb = now
        val root = rootInActiveWindow ?: return
        val txt = rootText()
        if ((txt.contains("instagram.com") || txt.contains("facebook.com")) && hasSignupText(root)) {
            kick("Naya account banana blocked")
        }
    }

    private fun inReels(key: String, root: AccessibilityNodeInfo): Boolean {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var n = 0
        while (queue.isNotEmpty() && n < 600) {
            val node = queue.removeFirst()
            n++
            val id = node.viewIdResourceName?.lowercase() ?: ""
            val desc = node.contentDescription?.toString()?.lowercase() ?: ""
            val hit = when (key) {
                "ig" -> id.contains("clips_viewer") || id.contains("reel_viewer") ||
                        (id.endsWith("clips_tab") && node.isSelected)
                "yt" -> id.contains("reel_recycler") || id.contains("reel_player_page_container") ||
                        id.contains("shorts_player")
                else -> id.contains("reels_viewer") || id.contains("reel_viewer") ||
                        (desc.startsWith("reels") && node.isSelected)
            }
            if (hit) return true
            for (i in 0 until node.childCount) node.getChild(i)?.let { queue.add(it) }
        }
        return false
    }

    // VPN settings screen (Clean Mind ka VPN entry / disconnect / forget) band
    private fun guardVpnScreen(): Boolean {
        val now = System.currentTimeMillis()
        if (now - lastVpnGuard < 400) return false
        lastVpnGuard = now
        val label = applicationInfo.loadLabel(packageManager).toString().lowercase()
        val t = rootText()
        if (t.contains(label) && (t.contains("vpn") || t.contains("always-on") ||
                    t.contains("forget") || t.contains("disconnect"))) {
            return kick("VPN band nahi hoga")
        }
        return false
    }

    // ================= Lock: system screens =================
    private fun guardSystemScreens(pkg: String, event: AccessibilityEvent): Boolean {
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return false
        val title = event.text.joinToString(" ").lowercase()
        val cls = event.className?.toString()?.lowercase() ?: ""
        val label = applicationInfo.loadLabel(packageManager).toString().lowercase()

        when {
            pkg == "com.android.vpndialogs" -> return kick("VPN band nahi hoga")
            pkg == "com.android.vending" ->
                if (title.contains("parental controls")) return kick("Lock ke time locked")
            pkg in settingsPkgs || pkg in installerPkgs -> {
                if (blockedTitles.any { title.contains(it) }) return kick("Lock chalu hai")
                val appInfo = title.contains("app info") || cls.contains("appdetails") ||
                        cls.contains("appinfo") || pkg in installerPkgs
                if (appInfo && rootText().contains(label)) return kick("Lock chalu hai")
            }
        }
        return false
    }

    // ================= Porn keyword scan =================
    private fun scanForPorn() {
        val now = System.currentTimeMillis()
        if (now - lastScan < 400) return
        lastScan = now
        val text = rootText()
        if (keywords.any { text.contains(it) }) kick("Blocked. Tu strong hai bhai 💪")
    }

    private fun rootText(): String {
        val root = rootInActiveWindow ?: return ""
        val sb = StringBuilder()
        var count = 0
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || count > 400) return
            count++
            n.text?.let { sb.append(it).append(' ') }
            n.contentDescription?.let { sb.append(it).append(' ') }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return sb.toString().lowercase()
    }

    private fun kick(msg: String): Boolean {
        performGlobalAction(GLOBAL_ACTION_HOME)
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        return true
    }

    private fun ensureVpn() {
        val now = System.currentTimeMillis()
        if (now - lastVpnCheck < 5000) return
        lastVpnCheck = now
        val wanted = getSharedPreferences("lock", MODE_PRIVATE).getBoolean("vpn_on", false)
        if (wanted && !DnsVpnService.active && VpnService.prepare(this) == null) {
            try { startService(Intent(this, DnsVpnService::class.java)) } catch (_: Exception) {}
        }
    }

    override fun onInterrupt() {}
}
