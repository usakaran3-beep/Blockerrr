package com.cleanmind.app

import android.app.Activity
import android.app.AlertDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val days = longArrayOf(7, 15, 30, 60, 180, 365)
    private val labels = arrayOf("7 din", "15 din", "1 mahina", "2 mahine", "6 mahine", "1 saal")
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable { override fun run() { refresh(); h.postDelayed(this, 30000) } }

    private lateinit var status: TextView
    private lateinit var btnAdmin: Button
    private lateinit var btnAcc: Button
    private lateinit var btnVpn: Button
    private lateinit var btnLock: Button
    private lateinit var group: RadioGroup
    private val appKeys = arrayOf("ig", "fb", "yt")
    private val appNames = arrayOf("Instagram", "Facebook", "YouTube")
    private val modeLabels = arrayOf("Off", "Sirf Reels/Shorts block", "Poora app block", "10 min reels, phir 5 min break")
    private val appGroups = mutableListOf<RadioGroup>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val admin get() = ComponentName(this, AdminReceiver::class.java)
    private val dpm get() = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(40), dp(20), dp(20))
        }
        root.addView(TextView(this).apply { text = "Clean Mind"; textSize = 26f })
        status = TextView(this).apply { textSize = 16f; setPadding(0, dp(12), 0, dp(12)) }
        root.addView(status)

        btnAdmin = Button(this).apply { text = "1. Device Admin ON karo"; setOnClickListener {
            startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
                .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Uninstall rokne ke liye"))
        } }
        btnAcc = Button(this).apply { text = "2. Accessibility ON karo"; setOnClickListener {
            Toast.makeText(this@MainActivity, "Clean Mind Blocker ko ON karo", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } }
        btnVpn = Button(this).apply { text = "3. Site Blocker (VPN) ON karo"; setOnClickListener {
            val i = VpnService.prepare(this@MainActivity)
            if (i != null) startActivityForResult(i, 1) else startVpn()
        } }
        root.addView(btnAdmin); root.addView(btnAcc); root.addView(btnVpn)

        root.addView(TextView(this).apply { text = "App blockers"; textSize = 16f; setPadding(0, dp(20), 0, dp(4)) })
        appKeys.forEachIndexed { i, k ->
            root.addView(TextView(this).apply { text = appNames[i]; setPadding(0, dp(8), 0, 0) })
            val rg = RadioGroup(this)
            modeLabels.forEachIndexed { m, l -> rg.addView(RadioButton(this).apply { text = l; id = 200 + i * 10 + m }) }
            rg.check(200 + i * 10 + getSharedPreferences("lock", MODE_PRIVATE).getInt("app_$k", 0))
            rg.setOnCheckedChangeListener { _, id ->
                getSharedPreferences("lock", MODE_PRIVATE).edit().putInt("app_$k", id - 200 - i * 10).apply()
            }
            appGroups.add(rg)
            root.addView(rg)
        }

        root.addView(TextView(this).apply { text = "Lock kitne time ke liye?"; textSize = 16f; setPadding(0, dp(20), 0, dp(4)) })
        group = RadioGroup(this)
        labels.forEachIndexed { i, l -> group.addView(RadioButton(this).apply { text = l; id = 100 + i }) }
        group.check(100)
        root.addView(group)

        btnLock = Button(this).apply { text = "🔒 LOCK KARO"; setOnClickListener { confirmLock() } }
        root.addView(btnLock)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun confirmLock() {
        val i = group.checkedRadioButtonId - 100
        AlertDialog.Builder(this)
            .setTitle("Pakka?")
            .setMessage("${labels[i]} tak uninstall, Settings ke screens aur VPN band rahenge. Undo nahi hoga.")
            .setPositiveButton("Haan, lock karo") { _, _ -> Lock.start(this, days[i]); refresh() }
            .setNegativeButton("Ruk", null).show()
    }

    private fun startVpn() {
        getSharedPreferences("lock", MODE_PRIVATE).edit().putBoolean("vpn_on", true).apply()
        startService(Intent(this, DnsVpnService::class.java))
        h.postDelayed({ refresh() }, 600)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == 1 && res == RESULT_OK) startVpn()
    }

    private fun accOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains("$packageName/${BlockerService::class.java.name}")
    }

    private fun refresh() {
        val a = dpm.isAdminActive(admin); val c = accOn(); val v = DnsVpnService.active
        val locked = Lock.isLocked(this)
        fun t(x: Boolean) = if (x) "✅" else "❌"
        var s = "${t(a)} Device Admin\n${t(c)} Accessibility\n${t(v)} Site Blocker (VPN)"
        if (locked) {
            val ms = Lock.remainingMs(this)
            s += "\n\n🔒 LOCKED: ${ms / 86400000} din ${(ms % 86400000) / 3600000} ghante baaki"
        }
        status.text = s
        btnAdmin.isEnabled = !locked; btnAcc.isEnabled = !locked; btnVpn.isEnabled = !locked || !v
        group.visibility = if (locked) View.GONE else View.VISIBLE
        appGroups.forEach { g -> for (j in 0 until g.childCount) g.getChildAt(j).isEnabled = !locked }
        btnLock.isEnabled = a && c && v && !locked
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
}
