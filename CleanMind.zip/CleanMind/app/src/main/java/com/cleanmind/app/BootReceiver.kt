package com.cleanmind.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val on = context.getSharedPreferences("lock", Context.MODE_PRIVATE).getBoolean("vpn_on", false)
        if (on && VpnService.prepare(context) == null) {
            try { context.startService(Intent(context, DnsVpnService::class.java)) } catch (_: Exception) {}
        }
    }
}
