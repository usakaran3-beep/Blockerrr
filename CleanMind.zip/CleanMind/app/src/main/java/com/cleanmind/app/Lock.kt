package com.cleanmind.app

import android.content.Context
import android.os.SystemClock
import android.provider.Settings

/** Lock timer. Wall clock + elapsedRealtime dono check hote hain, taaki time badalne se lock na tute. */
object Lock {
    private fun p(c: Context) = c.getSharedPreferences("lock", Context.MODE_PRIVATE)
    private fun boot(c: Context) = Settings.Global.getInt(c.contentResolver, Settings.Global.BOOT_COUNT, -1)

    fun start(c: Context, days: Long) {
        if (isLocked(c)) return
        val ms = days * 24L * 60 * 60 * 1000
        p(c).edit()
            .putLong("wallEnd", System.currentTimeMillis() + ms)
            .putLong("elapsedEnd", SystemClock.elapsedRealtime() + ms)
            .putInt("boot", boot(c))
            .apply()
    }

    fun remainingMs(c: Context): Long {
        val s = p(c)
        var left = s.getLong("wallEnd", 0) - System.currentTimeMillis()
        if (s.getInt("boot", -2) == boot(c)) {
            left = maxOf(left, s.getLong("elapsedEnd", 0) - SystemClock.elapsedRealtime())
        }
        return maxOf(left, 0)
    }

    fun isLocked(c: Context) = remainingMs(c) > 0
}
